document.querySelector("#vlibras")
document.querySelector("body > div.alert.alert-dismissible.text-center.cookiealert.show > div")